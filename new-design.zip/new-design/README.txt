# Ikkat Heritage House — HTML/CSS/JS Website

This package is an original Ikkat Heritage House storefront inspired by the premium editorial/e-commerce structure and shopping flow of the referenced Pratha Sarees website.

## Included
- index.html — homepage
- collections.html — product listing with search + sorting
- product.html — reusable product detail page (`product.html?id=1`)
- about.html — brand story
- css/style.css — responsive styling
- js/main.js — cart, quick view, filtering and interactions
- assets/products.js — product data
- assets/logo.jpg — supplied logo crop
- assets/products/ — supplied product/editorial images

## Important
Product prices in `assets/products.js` are demo values because no price list was supplied. Replace them with the actual prices before publishing.

The checkout button is a front-end placeholder. Connect it to Shopify/WooCommerce/custom payment/checkout APIs for live orders.

The website uses an original Ikkat Heritage visual system and original copy rather than copying Pratha's proprietary text, branding or assets.
