
let cart=JSON.parse(localStorage.getItem('ikkatCart')||'[]');
const money=n=>'₹'+Number(n).toLocaleString('en-IN');
function updateCart(){document.querySelectorAll('.cart-count').forEach(x=>x.textContent=cart.reduce((a,b)=>a+b.qty,0));const box=document.querySelector('#cartItems'),total=document.querySelector('#cartTotal');if(!box)return;if(!cart.length){box.innerHTML='<div class="no-results" style="padding:50px 10px">Your cart is empty.</div>';total.textContent='₹0';return}box.innerHTML=cart.map((x,i)=>`<div class="cart-item"><img src="${x.image}"><div style="flex:1"><b>${x.name}</b><div class="product-meta">${x.color}</div><div style="margin-top:8px">${money(x.price)} × ${x.qty}</div><button onclick="removeCart(${i})" style="margin-top:7px;border:0;background:none;padding:0;font-size:9px;text-transform:uppercase;letter-spacing:1px">Remove</button></div></div>`).join('');total.textContent=money(cart.reduce((a,b)=>a+b.price*b.qty,0))}
function addCart(id){const p=products.find(x=>x.id==id);const e=cart.find(x=>x.id==id);e?e.qty++:cart.push({...p,qty:1});localStorage.setItem('ikkatCart',JSON.stringify(cart));updateCart();openCart()}
function removeCart(i){cart.splice(i,1);localStorage.setItem('ikkatCart',JSON.stringify(cart));updateCart()}
function openCart(){document.querySelector('#cartPanel').classList.add('open');document.querySelector('#overlay').classList.add('show')}
function closeCart(){document.querySelector('#cartPanel').classList.remove('open');document.querySelector('#overlay').classList.remove('show')}
function renderProducts(list,target='#productGrid'){const el=document.querySelector(target);if(!el)return;el.innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image"><img loading="lazy" src="${p.image}" alt="${p.name}">${p.badge?`<span class="badge">${p.badge}</span>`:''}<button class="quick" onclick="quickView(${p.id})">Quick View</button></div><div class="product-info"><div class="product-name">${p.name}</div><div class="product-meta">${p.color} · Handwoven collection</div><div class="price">${money(p.price)}</div></div></article>`).join(''):'<div class="no-results" style="grid-column:1/-1">No sarees found.</div>'}
function quickView(id){const p=products.find(x=>x.id==id);document.querySelector('#modalContent').innerHTML=`<img src="${p.image}" alt="${p.name}"><div class="modal-info"><button class="close" onclick="closeModal()">×</button><div class="kicker">Ikkat Heritage House</div><h2>${p.name}</h2><p class="product-meta">${p.color} · Handwoven Ikat</p><h3 style="font-size:20px;margin-top:25px">${money(p.price)}</h3><p style="font-size:12px;line-height:2;color:#777">A thoughtfully selected handwoven piece from the Ikkat Heritage collection. Product specifications and availability can be confirmed before purchase.</p><div class="qty"><button>−</button><span>1</span><button>+</button></div><button class="btn" onclick="addCart(${p.id});closeModal()">Add to cart</button><a class="btn" style="margin-left:8px;background:#25D366;border-color:#25D366" href="https://wa.me/?text=I%20am%20interested%20in%20${encodeURIComponent(p.name)}" target="_blank">WhatsApp</a></div>`;document.querySelector('#productModal').classList.add('show')}
function closeModal(){document.querySelector('#productModal').classList.remove('show')}
function setupShop(){renderProducts(products);const search=document.querySelector('#searchInput'),sort=document.querySelector('#sort');function apply(){let list=[...products],q=(search?.value||'').toLowerCase();if(q)list=list.filter(p=>(p.name+' '+p.color).toLowerCase().includes(q));if(sort?.value==='low')list.sort((a,b)=>a.price-b.price);if(sort?.value==='high')list.sort((a,b)=>b.price-a.price);renderProducts(list)}search?.addEventListener('input',apply);sort?.addEventListener('change',apply)}
document.addEventListener('DOMContentLoaded',()=>{updateCart();setupShop();document.querySelectorAll('[data-cart]').forEach(x=>x.addEventListener('click',openCart));document.querySelector('#overlay')?.addEventListener('click',closeCart);document.querySelector('#closeCart')?.addEventListener('click',closeCart);document.querySelector('#closeModal')?.addEventListener('click',closeModal);document.querySelector('#year')&&(document.querySelector('#year').textContent=new Date().getFullYear())});

// Homepage category scroller
function setupCategoryStrip(){
  const track=document.querySelector('.category-track');
  const prev=document.querySelector('.cat-prev');
  const next=document.querySelector('.cat-next');
  if(!track)return;
  prev?.addEventListener('click',()=>track.scrollBy({left:-360,behavior:'smooth'}));
  next?.addEventListener('click',()=>track.scrollBy({left:360,behavior:'smooth'}));
}

// Homepage hero slider: autoplay + arrows + dots + swipe
function setupHeroSlider(){
  const slider=document.querySelector('.hero-slider');
  if(!slider)return;
  const slides=[...slider.querySelectorAll('.hero-slide')];
  const dots=[...slider.querySelectorAll('.hero-dot')];
  const prev=slider.querySelector('.hero-prev');
  const next=slider.querySelector('.hero-next');
  let index=0,timer;
  const show=(n)=>{
    index=(n+slides.length)%slides.length;
    slides.forEach((s,i)=>s.classList.toggle('is-active',i===index));
    dots.forEach((d,i)=>d.classList.toggle('is-active',i===index));
  };
  const restart=()=>{clearInterval(timer);timer=setInterval(()=>show(index+1),5000)};
  prev?.addEventListener('click',()=>{show(index-1);restart()});
  next?.addEventListener('click',()=>{show(index+1);restart()});
  dots.forEach((d,i)=>d.addEventListener('click',()=>{show(i);restart()}));
  let startX=0;
  slider.addEventListener('touchstart',e=>{startX=e.touches[0].clientX},{passive:true});
  slider.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-startX;if(Math.abs(dx)>45){show(index+(dx<0?1:-1));restart()}});
  slider.addEventListener('mouseenter',()=>clearInterval(timer));
  slider.addEventListener('mouseleave',restart);
  show(0);restart();
}

document.addEventListener('DOMContentLoaded',()=>{setupCategoryStrip();setupHeroSlider()});
