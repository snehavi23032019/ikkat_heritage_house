const products = [
  {
    "id": 1,
    "name": "Ikkat Heritage Ikat Silk Saree 01",
    "price": 4800,
    "category": "Ikat Sarees",
    "color": "Ruby Red",
    "image": "assets/products/IMG_0802.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 2,
    "name": "Ikkat Heritage Handwoven Ikat Saree 02",
    "price": 5250,
    "category": "Ikat Sarees",
    "color": "Royal Blue",
    "image": "assets/products/IMG_0803.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 3,
    "name": "Ikkat Heritage Heritage Ikat Saree 03",
    "price": 5900,
    "category": "Ikat Sarees",
    "color": "Fuchsia",
    "image": "assets/products/IMG_0804.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 4,
    "name": "Ikkat Heritage Ikat Zari Saree 04",
    "price": 6250,
    "category": "Ikat Sarees",
    "color": "Magenta",
    "image": "assets/products/IMG_0805.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 5,
    "name": "Ikkat Heritage Ikat Silk Saree 05",
    "price": 6800,
    "category": "Ikat Sarees",
    "color": "Emerald Green",
    "image": "assets/products/IMG_0806.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 6,
    "name": "Ikkat Heritage Handwoven Ikat Saree 06",
    "price": 7200,
    "category": "Ikat Sarees",
    "color": "Mustard Gold",
    "image": "assets/products/IMG_0807.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 7,
    "name": "Ikkat Heritage Heritage Ikat Saree 07",
    "price": 4800,
    "category": "Ikat Sarees",
    "color": "Lime Green",
    "image": "assets/products/IMG_0808.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 8,
    "name": "Ikkat Heritage Ikat Zari Saree 08",
    "price": 5250,
    "category": "Ikat Sarees",
    "color": "Violet",
    "image": "assets/products/IMG_0809.JPG.jpeg",
    "badge": "New Arrival"
  },
  {
    "id": 9,
    "name": "Ikkat Heritage Ikat Silk Saree 09",
    "price": 5900,
    "category": "Ikat Sarees",
    "color": "Plum Purple",
    "image": "assets/products/IMG_0810.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 10,
    "name": "Ikkat Heritage Handwoven Ikat Saree 10",
    "price": 6250,
    "category": "Ikat Sarees",
    "color": "Coral Red",
    "image": "assets/products/IMG_0811.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 11,
    "name": "Ikkat Heritage Heritage Ikat Saree 11",
    "price": 6800,
    "category": "Ikat Sarees",
    "color": "Ocean Teal",
    "image": "assets/products/IMG_0812.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 12,
    "name": "Ikkat Heritage Ikat Zari Saree 12",
    "price": 7200,
    "category": "Ikat Sarees",
    "color": "Pink & Purple",
    "image": "assets/products/IMG_0813.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 13,
    "name": "Ikkat Heritage Ikat Silk Saree 13",
    "price": 4800,
    "category": "Ikat Sarees",
    "color": "Crimson",
    "image": "assets/products/IMG_0815.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 14,
    "name": "Ikkat Heritage Handwoven Ikat Saree 14",
    "price": 5250,
    "category": "Ikat Sarees",
    "color": "Wine",
    "image": "assets/products/IMG_0816.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 15,
    "name": "Ikkat Heritage Heritage Ikat Saree 15",
    "price": 5900,
    "category": "Ikat Sarees",
    "color": "Rust Orange",
    "image": "assets/products/IMG_0817.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 16,
    "name": "Ikkat Heritage Ikat Zari Saree 16",
    "price": 6250,
    "category": "Ikat Sarees",
    "color": "Berry Pink",
    "image": "assets/products/IMG_0818.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 17,
    "name": "Ikkat Heritage Ikat Silk Saree 17",
    "price": 6800,
    "category": "Ikat Sarees",
    "color": "Peacock Blue",
    "image": "assets/products/IMG_0819.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 18,
    "name": "Ikkat Heritage Handwoven Ikat Saree 18",
    "price": 7200,
    "category": "Ikat Sarees",
    "color": "Ruby Red",
    "image": "assets/products/IMG_0822.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 19,
    "name": "Ikkat Heritage Heritage Ikat Saree 19",
    "price": 4800,
    "category": "Ikat Sarees",
    "color": "Royal Blue",
    "image": "assets/products/IMG_0823.JPG.jpeg",
    "badge": ""
  },
  {
    "id": 20,
    "name": "Ikkat Heritage Ikat Zari Saree 20",
    "price": 5250,
    "category": "Ikat Sarees",
    "color": "Fuchsia",
    "image": "assets/products/IMG_0824.JPG.jpeg",
    "badge": ""
  }
];
const editorialImages = ["assets/products/WhatsApp_Image_2026-08-25_at_9.05.24_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.07.09_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.09.14_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.10.38_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.12.29_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.13.14_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.15.34_PM.jpeg", "assets/products/WhatsApp_Image_2026-08-25_at_9.16.12_PM.jpeg"];
